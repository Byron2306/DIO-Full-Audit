> Draft educator aid: verify every suggested teaching use and CAPS scope before classroom use.

# HOMS Educator · Exam to Learning Crosswalk

**Life Skills · Grade 1 · Term unspecified**

This educator-only file maps the generated memo to teach-back and misconception checks. The learner guide receives prompts only; keep this file and the memorandum with educators.

## 1.1 · 4 marks

**Question:** 1.1 Name two healthy things Nandi does and give one reason each is healthy. [4]

**Bloom / family:** remember / identify_and_explain

**Memo points (educator use):**
- Names washing hands before eating.
- Names taking clean water.
- Gives one reason clean hands help keep a person healthy.
- Gives one reason drinking clean water is helpful.

## 1.2 · 4 marks

**Question:** 1.2 What does Nandi do to use the slide safely? Give one other safe playground action and explain how each action helps keep children safe. [4]

**Bloom / family:** understand / scenario_response

**Memo points (educator use):**
- Says she waits for her turn.
- Gives one other safe action, such as using equipment as intended.
- Explains how waiting for a turn helps prevent a collision or fall.
- Explains how the other safe action helps prevent someone getting hurt.

## 1.3 · 4 marks

**Question:** 1.3 Her friend falls. Name four safe things Nandi can do while getting help. [4]

**Bloom / family:** apply / safety_sequence

**Memo points (educator use):**
- Calls the teacher or another trusted adult.
- Stays with the friend if it is safe.
- Does not move an injured person who may be seriously hurt.
- Uses calm, kind words while getting help.

## 1.4 · 4 marks

**Question:** 1.4 Starting with washing hands, put these actions in a helpful order: wash hands, sit to eat, play with a ball, tidy the ball away. [4]

**Bloom / family:** apply / sequence

**Memo points (educator use):**
- Puts washing hands before eating.
- Puts sitting to eat after washing hands.
- Puts playing with the ball before tidying it away.
- Gives a sensible complete order with all four actions.

## 1.5 · 4 marks

**Question:** 1.5 Give one kind way to help a classmate, say what you would do, and explain how it would help. [4]

**Bloom / family:** understand / short_response

**Memo points (educator use):**
- Names a specific kind action.
- Explains how the action helps the classmate.
- Uses respectful words or behaviour.
- Chooses an action that is safe and realistic at school.

## Review

Confirm that the teaching sequence prepares learners for the assessment without teaching to a leaked answer key. Recheck memo accuracy and source permissions before classroom use.
