> Draft educator aid: verify every suggested teaching use and CAPS scope before classroom use.

# HOMS Educator · Exam to Learning Crosswalk

**Business Studies · Grade 12 · Term unspecified**

This educator-only file maps the generated memo to teach-back and misconception checks. The learner guide receives prompts only; keep this file and the memorandum with educators.

## 1.1 · 8 marks

**Question:** 1.1 The Consumer Protection Act is part of the Grade 12 CAPS topic on the impact of recent legislation. Using the ingredient information in the case, explain how this law could affect Koru's label decisions, state one check the owners should make before printing, and explain one possible effect of a misleading description. [8]

**Bloom / family:** analyze / business_environment

**Memo points (educator use):**
- Names the Consumer Protection Act as relevant legislation.
- Classifies legislation as an external macro-environment influence.
- Explains that a trade description must not mislead consumers.
- Applies that principle to ingredient information on Koru's packet label.
- Explains that accurate information helps customers make informed choices.
- Gives a concrete check, such as comparing the label with the current recipe or production record.
- States that current, applicable food-labelling requirements should be checked before printing.
- Explains one possible consequence of a misleading description, such as a misled customer, complaint, loss of trust or legal risk.

## 1.2 · 9 marks

**Question:** 1.2 Explain two different considerations before buying the drying machine. Use case details and identify a cost, sales or production estimate to check, plus one worker training or safety issue. [9]

**Bloom / family:** apply / decision_analysis

**Memo points (educator use):**
- Considers purchase/operating cost.
- Considers whether expected sales can cover the cost.
- Considers production capacity or consistent orders.
- Considers worker training.
- Considers workplace safety.
- Uses the case details.
- Explains rather than lists one consideration.
- Explains a second distinct consideration.
- States that the comparison should use estimates or records rather than assumption.

## 1.3 · 10 marks

**Question:** 1.3 Explain why accurate ingredient information and fair supplier relationships matter. [10]

**Bloom / family:** understand / ethics_and_stakeholders

**Memo points (educator use):**
- States ingredient information should be accurate.
- Links accuracy to informed customer choice or safety.
- States that the label should be checked against applicable requirements before printing.
- Identifies nearby farmers as suppliers.
- Explains that fair supplier relationships support reliable sourcing.
- Links reliable sourcing to product consistency.
- Identifies a fair-trading practice, such as agreeing quantities, quality, price or payment terms.
- Shows that responsible conduct affects trust.
- Uses case evidence.
- Connects accurate information or fair supplier terms to a business outcome such as customer trust, reliable supply or consistent quality.

## 1.4 · 11 marks

**Question:** 1.4 Evaluate the supermarket offer: give one opportunity and two risks the owners should investigate. [11]

**Bloom / family:** evaluate / opportunity_risk

**Memo points (educator use):**
- Identifies access to a larger sales channel as an opportunity.
- Links opportunity to potential growth.
- Identifies risk of being unable to meet larger orders.
- Identifies a quality-consistency risk.
- Considers the machine cost or cash-flow risk.
- Explains one risk using case evidence.
- Explains a second risk distinctly.
- States information needed before deciding.
- Explains that higher sales do not establish profit until expected order value is compared with costs.
- Balances opportunity and risk.
- Gives a supported conclusion.

## 1.5 · 12 marks

**Question:** 1.5 Recommend whether Koru should accept the offer now, delay, or negotiate conditions. Support your recommendation with evidence and two practical conditions. [12]

**Bloom / family:** evaluate / recommendation

**Memo points (educator use):**
- Makes a clear recommendation.
- Uses the larger-order requirement as evidence.
- Uses the need for consistent quality as evidence.
- Considers machine cost or capacity.
- Names a first practical condition.
- Names a second distinct condition.
- Includes worker training/safety or supplier readiness.
- Includes accurate ingredient packaging.
- Explains how conditions reduce risk.
- Considers stakeholder relationships.
- Names a measurable trigger for scaling up, such as a successful trial order or confirmed production capacity.
- Presents a logically supported conclusion.

## Review

Confirm that the teaching sequence prepares learners for the assessment without teaching to a leaked answer key. Recheck memo accuracy and source permissions before classroom use.
