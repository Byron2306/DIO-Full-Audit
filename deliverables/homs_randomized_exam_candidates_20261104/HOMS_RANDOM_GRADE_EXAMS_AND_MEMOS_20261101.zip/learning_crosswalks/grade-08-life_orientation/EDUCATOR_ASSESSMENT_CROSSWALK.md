> Draft educator aid: verify every suggested teaching use and CAPS scope before classroom use.

# HOMS Educator · Exam to Learning Crosswalk

**Life Orientation · Grade 8 · Term unspecified**

This educator-only file maps the generated memo to teach-back and misconception checks. The learner guide receives prompts only; keep this file and the memorandum with educators.

## 1.1 · 6 marks

**Question:** 1.1 Explain how pressure from a friend could affect the learner’s confidence in their own ability. Write one positive self-talk statement and give one action that would help the learner use their own ability on the assignment. [6]

**Bloom / family:** understand / scenario_analysis

**Memo points (educator use):**
- Identifies the friend's pressure to copy as an influence on the learner.
- Explains one possible effect on confidence or self-concept, such as doubting their own ability.
- Writes a positive and relevant self-talk statement that recognizes their ability or individuality.
- Connects the self-talk statement to completing their own original work.
- Gives one practical action, such as starting a small task or asking the teacher for help.
- Explains how the action could support confidence or develop personal potential.

## 1.2 · 6 marks

**Question:** 1.2 Create a two-week plan with three milestones and one leisure period. [6]

**Bloom / family:** apply / planning

**Memo points (educator use):**
- Includes a first milestone soon after today.
- Includes a middle progress check.
- Includes a final review before the due date.
- Includes a leisure period.
- Orders the milestones sensibly.
- Makes the plan achievable.

## 1.3 · 8 marks

**Question:** 1.3 Compare asking the teacher for help with copying a classmate's work. [8]

**Bloom / family:** analyze / comparison

**Memo points (educator use):**
- Names a benefit of asking for help.
- Names a limitation or effort involved in asking for help.
- Names a short-term perceived benefit of copying.
- Identifies an academic-integrity risk of copying.
- Considers learning gained from original work.
- Uses the school rule in the scenario.
- Distinguishes the two choices.
- Gives a supported comparison.

## 1.4 · 10 marks

**Question:** 1.4 Write a respectful message to a friend explaining a boundary about copying while preserving the friendship. [10]

**Bloom / family:** apply / transactional_writing

**Memo points (educator use):**
- States clearly that the learner will not copy.
- Uses respectful language.
- Avoids insulting or threatening the friend.
- Gives a brief reason based on learning or honesty.
- Offers a constructive alternative.
- Keeps the friendship in view.
- Uses an appropriate greeting or opening.
- Makes the message coherent.
- Uses suitable punctuation.
- Maintains a calm tone.

## 1.5 · 10 marks

**Question:** 1.5 Recommend one help-seeking step and explain how the learner can monitor progress. [10]

**Bloom / family:** evaluate / help_seeking

**Memo points (educator use):**
- Names an appropriate trusted school support person.
- States a clear question or request for help.
- Connects help-seeking to the assignment.
- Sets a measurable first task.
- Sets a date to check progress.
- Uses the two-week deadline.
- Includes a way to respond if behind schedule.
- Protects time for rest or leisure.
- Explains why monitoring helps.
- Gives a justified recommendation.

## Review

Confirm that the teaching sequence prepares learners for the assessment without teaching to a leaked answer key. Recheck memo accuracy and source permissions before classroom use.
