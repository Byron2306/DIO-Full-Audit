> Draft educator aid: verify every suggested teaching use and CAPS scope before classroom use.

# HOMS Educator · Exam to Learning Crosswalk

**Physical Sciences · Grade 10 · Term unspecified**

This educator-only file maps the generated memo to teach-back and misconception checks. The learner guide receives prompts only; keep this file and the memorandum with educators.

## 1.1 · 8 marks

**Question:** 1.1 Distinguish distance and displacement, then calculate both for the trolley's first 6 s of motion. [8]

**Bloom / family:** understand / concept_and_calculation

**Memo points (educator use):**
- Defines distance as total path length.
- Defines displacement as change in position with direction.
- Identifies the start at -4 m, turning position at +20 m and final position at +8 m.
- Calculates the eastward segment as 24 m and westward segment as 12 m.
- Adds segment lengths to give distance 36 m.
- Calculates displacement as +8 - (-4) = +12 m.
- States displacement is 12 m east.
- Uses metres for distance and displacement.

## 1.2 · 9 marks

**Question:** 1.2 For the first 6 s, calculate the trolley's average velocity and average speed. State one difference between them. [9]

**Bloom / family:** apply / calculation

**Memo points (educator use):**
- Uses displacement +12 m to calculate average velocity.
- Uses total distance 36 m to calculate average speed.
- Uses the total time interval 6 s for both calculations.
- States average velocity = displacement / time.
- Substitutes values correctly and obtains +2 m·s⁻¹ east.
- States average speed = distance / time.
- Substitutes values correctly and obtains 6 m·s⁻¹.
- Uses correct SI units.
- Explains that velocity includes direction and uses displacement, while speed has no direction and uses distance.

## 1.3 · 10 marks

**Question:** 1.3 Calculate acceleration during the later interval and state what its sign means. [10]

**Bloom / family:** apply / calculation_and_interpretation

**Memo points (educator use):**
- Identifies initial velocity +3 m·s⁻¹.
- Identifies final velocity +15 m·s⁻¹.
- Uses time interval 4 s.
- Uses a = (v_f - v_i)/Δt.
- Calculates change in velocity +12 m·s⁻¹.
- Divides by 4 s.
- Gives +3 m·s⁻².
- Uses correct SI units.
- States acceleration is in the positive/east direction.
- Connects positive acceleration to increasing positive velocity.

## 1.4 · 11 marks

**Question:** 1.4 Assume the later acceleration stays constant at the value from Question 1.3 for a further 3 s, starting at +15 m·s⁻¹. Calculate the final velocity and signed displacement. Draw a velocity-time graph for this interval or show the trapezium area calculation, and state the direction. [11]

**Bloom / family:** apply / multi_step_calculation

**Memo points (educator use):**
- Uses the initial velocity +15 m·s⁻¹.
- Uses the acceleration +3 m·s⁻².
- Uses the time interval 3 s.
- Chooses v_f = v_i + aΔt.
- Substitutes the stated values correctly.
- Calculates the velocity change as +9 m·s⁻¹.
- Gives final velocity +24 m·s⁻¹.
- Draws or identifies the velocity-time trapezium with endpoint velocities +15 m·s⁻¹ and +24 m·s⁻¹ over 3 s, or states an equivalent area method.
- Substitutes ½(15 + 24) × 3 or an equivalent average-velocity method.
- Calculates signed displacement +58.5 m.
- Gives the displacement direction as east and uses correct units.

## 1.5 · 12 marks

**Question:** 1.5 Compare a position-time graph and a velocity-time graph. For each graph, name both axes and give their units; state what its gradient represents and what a horizontal line means. For the velocity-time graph, state what the signed area represents. [12]

**Bloom / family:** analyze / graph_interpretation

**Memo points (educator use):**
- Names position as the vertical-axis quantity on the position-time graph.
- Names time as the horizontal-axis quantity on the position-time graph.
- Gives metres (m) for position and seconds (s) for time on the position-time graph.
- Names velocity as the vertical-axis quantity on the velocity-time graph.
- Names time as the horizontal-axis quantity on the velocity-time graph.
- Gives metres per second (m·s⁻¹) for velocity and seconds (s) for time on the velocity-time graph.
- States that the gradient of a position-time graph represents velocity.
- States that the gradient of a velocity-time graph represents acceleration.
- States that the signed area under a velocity-time graph represents displacement.
- Explains that a horizontal position-time line means position is constant.
- Explains that a horizontal velocity-time line means velocity is constant.
- Clearly distinguishes the quantity shown directly by each graph.

## Review

Confirm that the teaching sequence prepares learners for the assessment without teaching to a leaked answer key. Recheck memo accuracy and source permissions before classroom use.
