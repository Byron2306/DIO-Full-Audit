# Evidex EvidenceOps · claim reconciliation review candidate

This customer-first report reconciles a synthetic 14-workshop claim against a summary that says attendance sheets support 12. It calculates a reported −2 difference but explicitly refuses to treat the quantities as comparable or verified because the original registers, reporting period, population and source authenticity are unavailable. Email-only mentions and undated photographs are kept as leads, not counted as delivery evidence.

Open `CUSTOMER_RECONCILIATION_REPORT.pdf` for the printable customer deliverable or the HTML version for a searchable copy. The source summaries, structured customer evidence review, reference adjudication, mechanical comparison and expert rubric are included separately as the assurance appendix. This is synthetic controlled evidence, not a real customer case; expert review and release remain pending.
