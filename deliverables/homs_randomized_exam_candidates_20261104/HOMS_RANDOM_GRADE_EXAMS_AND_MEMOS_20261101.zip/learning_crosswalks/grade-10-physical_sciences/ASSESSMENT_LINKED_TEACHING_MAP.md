# HOMS Learning Studio · Exam-linked teaching map

> Generated from the same source-bound, educator-review-required spine as the exam. Draft planning aid only; question-level CAPS clause mapping is not asserted.

**Subject:** Physical Sciences  
**Grade / phase:** 10 / fet_grade_10_12  
**Term:** Unspecified  
**Bloom targets:** analyze, apply, understand

## Learning sequence anchored to the assessment

| Exam item | Prompt | Marks | Bloom / question type | Teaching use |
|---|---|---:|---|---|
| 1.1 | 1.1 Distinguish distance and displacement, then calculate both for the trolley's first 6 s of motion. [8] | 8 | understand / concept_and_calculation | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.2 | 1.2 For the first 6 s, calculate the trolley's average velocity and average speed. State one difference between them. [9] | 9 | apply / calculation | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.3 | 1.3 Calculate acceleration during the later interval and state what its sign means. [10] | 10 | apply / calculation_and_interpretation | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.4 | 1.4 Assume the later acceleration stays constant at the value from Question 1.3 for a further 3 s, starting at +15 m·s⁻¹. Calculate the final velocity and signed displacement. Draw a velocity-time graph for this interval or show the trapezium area calculation, and state the direction. [11] | 11 | apply / multi_step_calculation | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.5 | 1.5 Compare a position-time graph and a velocity-time graph. For each graph, name both axes and give their units; state what its gradient represents and what a horizontal line means. For the velocity-time graph, state what the signed area represents. [12] | 12 | analyze / graph_interpretation | Use as a retrieval check; teach prerequisite concepts before re-attempt. |

## Sources and visuals

- CAPS: Physical Sciences · SHA-256 `8b7b20f350a46fc077c4e9b2fcf4ecfd7b63e7f6cd56d7d6ea94de75dbcd209f`

## Educator-only memo bridge

The matching memo remains a separate teacher artifact. Use it to build worked examples and misconception checks; do not place the memo in the learner-facing exam copy.

## Release gate

Subject expert verifies curriculum fit, source rights, answer accuracy, visual legibility, accessibility and classroom suitability before release.
