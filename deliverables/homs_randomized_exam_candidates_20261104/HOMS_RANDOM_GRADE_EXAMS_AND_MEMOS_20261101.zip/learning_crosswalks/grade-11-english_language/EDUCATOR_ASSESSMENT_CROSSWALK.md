> Draft educator aid: verify every suggested teaching use and CAPS scope before classroom use.

# HOMS Educator · Exam to Learning Crosswalk

**English Language · Grade 11 · Term unspecified**

This educator-only file maps the generated memo to teach-back and misconception checks. The learner guide receives prompts only; keep this file and the memorandum with educators.

## 1.1 · 8 marks

**Question:** 1.1 State the route problem. Give two details showing the conditions learners faced, and explain one reason the repair mattered. [8]

**Bloom / family:** analyze / comprehension

**Memo points (educator use):**
- Identifies the muddy patch as the route problem.
- States that the patch was between the gate and the bicycle racks.
- Uses the detail that learners crossed it for months.
- Uses the detail that it became slippery after heavy rain.
- Explains that a slippery path can create a risk of slipping or falling.
- Explains how the route affected learners moving between the gate and bicycle racks.
- Supports the response with two relevant details from the passage.
- Writes a clear answer that separates evidence from explanation.

## 1.2 · 9 marks

**Question:** 1.2 Identify the two environmental choices in the club's plan and explain the purpose of each. [9]

**Bloom / family:** understand / inference

**Memo points (educator use):**
- Identifies drainage into the garden.
- Identifies the planted strip beside the path.
- Explains that drainage prevents blocking water flow.
- Explains that plants provide habitat/space for insects or flowers.
- Connects the choices to the project design.
- Uses text evidence.
- Separates the two environmental choices.
- Uses an appropriate cause-effect link.
- Gives a clear answer.

## 1.3 · 10 marks

**Question:** 1.3 Use the survey table to compare daily and occasional route use. Calculate the percentage in each group and write one accurate sentence describing what the figures show. [10]

**Bloom / family:** analyze / visual_data_interpretation

**Memo points (educator use):**
- Reads 42 learners in the every-day group.
- Reads 18 learners in the sometimes group.
- Uses 60 as the total number surveyed.
- Sets up 42/60 x 100 for daily use.
- Simplifies 42/60 to 7/10 or an equivalent fraction.
- Calculates 70% for daily use.
- Sets up 18/60 x 100 for sometimes use.
- Calculates 30% for sometimes use.
- Correctly compares the two proportions (70% versus 30%, or 42 versus 18 learners).
- Writes a clear sentence that accurately describes the comparison.

## 1.4 · 11 marks

**Question:** 1.4 Assess one strength and one limitation of the club's feedback method. [11]

**Bloom / family:** evaluate / evaluation

**Memo points (educator use):**
- Identifies the two-week follow-up as a strength.
- Explains that users can comment after trying the path.
- Identifies that the passage says 'most replies' without giving a count.
- Explains that the response total is unknown.
- Notes that only route users may have been asked or another defensible limitation.
- Uses evidence from the text.
- Distinguishes strength from limitation.
- Avoids inventing a survey sample size.
- Makes a supported judgment.
- Uses clear paragraph structure.
- Uses appropriate analytical language.

## 1.5 · 12 marks

**Question:** 1.5 Write a short recommendation to the eco-club about its next step, using evidence from the passage. [12]

**Bloom / family:** evaluate / evidence_based_writing

**Memo points (educator use):**
- Makes one clear next-step recommendation.
- Addresses the requested wider entrance feedback.
- Uses the positive replies as relevant evidence.
- Recognises the follow-up response count is not reported.
- Suggests collecting a count or specific user feedback.
- Keeps drainage in the design.
- Keeps the planted strip in the design or explains any change.
- Names who should be consulted.
- Gives a practical action.
- Explains expected benefit.
- Uses a formal, suitable tone.
- Organises the recommendation coherently.

## Review

Confirm that the teaching sequence prepares learners for the assessment without teaching to a leaked answer key. Recheck memo accuracy and source permissions before classroom use.
