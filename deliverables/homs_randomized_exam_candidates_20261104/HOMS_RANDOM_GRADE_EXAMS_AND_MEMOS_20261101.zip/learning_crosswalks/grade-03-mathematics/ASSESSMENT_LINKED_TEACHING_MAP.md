# HOMS Learning Studio · Exam-linked teaching map

> Generated from the same source-bound, educator-review-required spine as the exam. Draft planning aid only; question-level CAPS clause mapping is not asserted.

**Subject:** Mathematics  
**Grade / phase:** 3 / foundation_grade_r_3  
**Term:** Unspecified  
**Bloom targets:** apply, understand

## Learning sequence anchored to the assessment

| Exam item | Prompt | Marks | Bloom / question type | Teaching use |
|---|---|---:|---|---|
| 1.1 | 1.1 How many bottle tops did the class collect altogether? Show your addition. [4] | 4 | apply / calculation | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.2 | 1.2 Use your total from Question 1.1 to put the bottle tops into bags of 6. Show a calculation or equal-groups drawing. State how many full bags you can make and whether any tops are left. [4] | 4 | apply / equal_grouping | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.3 | 1.3 Complete the pattern 5, 10, 15, __, __, state its rule and give the number that would be in the eighth position. [4] | 4 | understand / pattern | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.4 | 1.4 A ribbon is 35 cm long. Sipho uses 12 cm. How much remains? [4] | 4 | apply / measurement | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.5 | 1.5 Name one 2-D shape with four straight sides and one object with that shape. [4] | 4 | understand / geometry | Use as a retrieval check; teach prerequisite concepts before re-attempt. |

## Sources and visuals

- CAPS: Mathematics · SHA-256 `e3b5bc415912b6f0eb13ca8d18a57d7c951d23b399e20f38315fc13f2feed011`

## Educator-only memo bridge

The matching memo remains a separate teacher artifact. Use it to build worked examples and misconception checks; do not place the memo in the learner-facing exam copy.

## Release gate

Subject expert verifies curriculum fit, source rights, answer accuracy, visual legibility, accessibility and classroom suitability before release.
