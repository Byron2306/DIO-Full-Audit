# HOMS Learning Studio · Exam-linked teaching map

> Generated from the same source-bound, educator-review-required spine as the exam. Draft planning aid only; question-level CAPS clause mapping is not asserted.

**Subject:** Business Studies  
**Grade / phase:** 12 / fet_grade_10_12  
**Term:** Unspecified  
**Bloom targets:** analyze, apply, evaluate, understand

## Learning sequence anchored to the assessment

| Exam item | Prompt | Marks | Bloom / question type | Teaching use |
|---|---|---:|---|---|
| 1.1 | 1.1 The Consumer Protection Act is part of the Grade 12 CAPS topic on the impact of recent legislation. Using the ingredient information in the case, explain how this law could affect Koru's label decisions, state one check the owners should make before printing, and explain one possible effect of a misleading descript | 8 | analyze / business_environment | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.2 | 1.2 Explain two different considerations before buying the drying machine. Use case details and identify a cost, sales or production estimate to check, plus one worker training or safety issue. [9] | 9 | apply / decision_analysis | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.3 | 1.3 Explain why accurate ingredient information and fair supplier relationships matter. [10] | 10 | understand / ethics_and_stakeholders | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.4 | 1.4 Evaluate the supermarket offer: give one opportunity and two risks the owners should investigate. [11] | 11 | evaluate / opportunity_risk | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.5 | 1.5 Recommend whether Koru should accept the offer now, delay, or negotiate conditions. Support your recommendation with evidence and two practical conditions. [12] | 12 | evaluate / recommendation | Use as a retrieval check; teach prerequisite concepts before re-attempt. |

## Sources and visuals

- CAPS: Business Studies · SHA-256 `e6f0a21b96fa87ccfccb732a9240a579bf0157916b86a1cdd98a2876cf76db27`

## Educator-only memo bridge

The matching memo remains a separate teacher artifact. Use it to build worked examples and misconception checks; do not place the memo in the learner-facing exam copy.

## Release gate

Subject expert verifies curriculum fit, source rights, answer accuracy, visual legibility, accessibility and classroom suitability before release.
