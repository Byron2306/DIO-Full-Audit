# Site-matched organ art candidates

These assets were generated through Pictora's local ComfyUI adapter, with the current DIO Workflows `dio-hero-product-2026.webp` uploaded as an image-to-image anchor. The outputs keep its obsidian black field, concentric gold orbits, filigree, and luminous central focus more faithfully than the previous text-only attempts.

- **Sonoris:** the inpaint-refined version now has a visibly recognizable piano on the central stage while retaining the orbital geometry. Preferred larger copy: `assets/SONORIS_MUSICAL_ORGAN_HERO_1280x720.png`.
- **Pictora:** the inpaint-refined version now presents a clear blue-sky landscape inside a gold image portal, making the image-generation idea legible within the site aesthetic. Preferred larger copy: `assets/PICTORA_IMAGE_FORGE_HERO_1280x720.png`.

Both final candidates were upscaled locally with RealESRGAN to 1280×720. They retain the site reference hash, source image hashes, mask hashes, ComfyUI workflows and job receipts, and remain `release_authorized: false`. Nothing was added to or published from the DIO Workflows website repository. Owner review is still needed before using them as live site heroes.
