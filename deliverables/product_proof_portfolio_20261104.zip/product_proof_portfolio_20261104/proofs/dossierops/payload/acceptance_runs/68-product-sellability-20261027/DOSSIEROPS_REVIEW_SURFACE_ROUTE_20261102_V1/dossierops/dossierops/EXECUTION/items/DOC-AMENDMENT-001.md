# Customer-supplied amendment draft

Record ID: DOC-AMENDMENT-001
Dated: 18 April 2026
Status declared by customer: UNSIGNED DRAFT

No signature block is completed in this supplied draft. Do not treat it as an executed amendment.
