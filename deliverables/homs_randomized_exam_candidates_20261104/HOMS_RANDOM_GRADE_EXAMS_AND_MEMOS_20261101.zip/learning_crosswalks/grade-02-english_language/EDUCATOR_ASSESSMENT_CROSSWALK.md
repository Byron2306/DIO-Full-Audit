> Draft educator aid: verify every suggested teaching use and CAPS scope before classroom use.

# HOMS Educator · Exam to Learning Crosswalk

**English Language · Grade 2 · Term unspecified**

This educator-only file maps the generated memo to teach-back and misconception checks. The learner guide receives prompts only; keep this file and the memorandum with educators.

## 1.1 · 4 marks

**Question:** 1.1 When and where did Class Two plant the bean seeds? What did Asha put by each pot? [4]

**Bloom / family:** remember / retrieve_specific_details

**Memo points (educator use):**
- States that the seeds were planted on Monday.
- States that they were planted beside the classroom.
- Identifies the seeds as bean seeds.
- Says that Asha put a name label by each pot.

## 1.2 · 4 marks

**Question:** 1.2 Name two things the class did to help the seeds grow. What did they use to measure the shoots, and when did two shoots appear? [4]

**Bloom / family:** understand / retrieve_multiple_details

**Memo points (educator use):**
- Says the class added a little water.
- Says the pots were placed near a sunny window.
- Identifies paper strips as the measuring tool.
- States that two shoots appeared on Friday.

## 1.3 · 4 marks

**Question:** 1.3 Give two reasons the class watered the pots only when the soil felt dry. Explain how this helped save water and keep the plants healthy. [4]

**Bloom / family:** understand / infer_reason

**Memo points (educator use):**
- Identifies the dry soil as the cue for watering.
- Explains that waiting until the soil is dry avoids unnecessary watering and saves water.
- Explains that watering when needed helps the plants while avoiding too much water.
- Links both reasons to the class's decision to check the soil before watering.

## 1.4 · 4 marks

**Question:** 1.4 Change this sentence to describe one pot: 'The pots are near a sunny window.' [4]

**Bloom / family:** apply / language_structures

**Memo points (educator use):**
- Changes the plural noun 'pots' to the singular 'pot'.
- Changes 'are' to 'is' to match the singular noun.
- Uses 'A' or 'One' before 'pot' to show that there is one pot.
- Writes a complete sentence with a capital letter and a full stop.

## 1.5 · 4 marks

**Question:** 1.5 Write two sentences about how you would care for a class plant. [4]

**Bloom / family:** apply / short_composition

**Memo points (educator use):**
- Gives one suitable plant-care action.
- Gives a second suitable plant-care action.
- Uses two complete, understandable sentences.
- Uses capitals and end punctuation correctly.

## Review

Confirm that the teaching sequence prepares learners for the assessment without teaching to a leaked answer key. Recheck memo accuracy and source permissions before classroom use.
