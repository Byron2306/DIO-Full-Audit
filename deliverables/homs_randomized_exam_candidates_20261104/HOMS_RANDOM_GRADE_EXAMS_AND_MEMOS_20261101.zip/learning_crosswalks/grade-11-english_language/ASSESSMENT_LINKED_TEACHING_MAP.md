# HOMS Learning Studio · Exam-linked teaching map

> Generated from the same source-bound, educator-review-required spine as the exam. Draft planning aid only; question-level CAPS clause mapping is not asserted.

**Subject:** English Language  
**Grade / phase:** 11 / fet_grade_10_12  
**Term:** Unspecified  
**Bloom targets:** analyze, evaluate, understand

## Learning sequence anchored to the assessment

| Exam item | Prompt | Marks | Bloom / question type | Teaching use |
|---|---|---:|---|---|
| 1.1 | 1.1 State the route problem. Give two details showing the conditions learners faced, and explain one reason the repair mattered. [8] | 8 | analyze / comprehension | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.2 | 1.2 Identify the two environmental choices in the club's plan and explain the purpose of each. [9] | 9 | understand / inference | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.3 | 1.3 Use the survey table to compare daily and occasional route use. Calculate the percentage in each group and write one accurate sentence describing what the figures show. [10] | 10 | analyze / visual_data_interpretation | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.4 | 1.4 Assess one strength and one limitation of the club's feedback method. [11] | 11 | evaluate / evaluation | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.5 | 1.5 Write a short recommendation to the eco-club about its next step, using evidence from the passage. [12] | 12 | evaluate / evidence_based_writing | Use as a retrieval check; teach prerequisite concepts before re-attempt. |

## Sources and visuals

- CAPS: English · SHA-256 `3d97f707a8ad56b58713ecd3a7e0ca8cf8698ba367e128a647718f7a47067407`

## Educator-only memo bridge

The matching memo remains a separate teacher artifact. Use it to build worked examples and misconception checks; do not place the memo in the learner-facing exam copy.

## Release gate

Subject expert verifies curriculum fit, source rights, answer accuracy, visual legibility, accessibility and classroom suitability before release.
