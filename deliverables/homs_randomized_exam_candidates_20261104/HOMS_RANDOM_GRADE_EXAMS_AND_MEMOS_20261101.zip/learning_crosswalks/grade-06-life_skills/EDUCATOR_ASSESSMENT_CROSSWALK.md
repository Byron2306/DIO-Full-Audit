> Draft educator aid: verify every suggested teaching use and CAPS scope before classroom use.

# HOMS Educator · Exam to Learning Crosswalk

**Life Skills · Grade 6 · Term unspecified**

This educator-only file maps the generated memo to teach-back and misconception checks. The learner guide receives prompts only; keep this file and the memorandum with educators.

## 1.1 · 5 marks

**Question:** 1.1 Identify Thabo’s late-night habit and the activity he has stopped joining. State one effect in class and explain how his habit may contribute to it. [5]

**Bloom / family:** understand / scenario_analysis

**Memo points (educator use):**
- States that Thabo watches videos after doing homework.
- States that he has been sleeping late.
- States that he has stopped joining football at break.
- States that he feels tired in class.
- Explains that watching videos late delays sleep and may contribute to tiredness in class.

## 1.2 · 5 marks

**Question:** 1.2 Suggest a realistic evening plan with a time for homework, a screen-free period before bed and one sleep-preparation activity. Put the activities in a sensible order and explain how the plan could support rest. [5]

**Bloom / family:** apply / planning

**Memo points (educator use):**
- Gives a reasonable time or duration for homework.
- Schedules a screen-free period before bed.
- Names a suitable sleep-preparation activity.
- Orders the activities sensibly before bedtime.
- Explains how the plan could support adequate rest.

## 1.3 · 6 marks

**Question:** 1.3 What could Thabo say to his friend? Write a respectful I-statement that names how he feels and why, asks for specific support, and names a trusted adult he could approach if the problem continues. Explain why asking for support is responsible. [6]

**Bloom / family:** apply / communication

**Memo points (educator use):**
- Names a feeling accurately.
- Gives a reason linked to the scenario.
- Uses a respectful I-statement or equivalent wording.
- Makes a clear, specific request for support from the friend.
- Identifies a trusted adult he could approach if the problem continues.
- Explains that asking for support is a responsible way to address a problem.

## 1.4 · 7 marks

**Question:** 1.4 Give two benefits of regular physical activity. Then suggest safe steps for Thabo's gradual return to football, including how to prepare, when to rest, and what to do if he feels unwell. [7]

**Bloom / family:** understand / wellbeing

**Memo points (educator use):**
- Names one health or mood benefit.
- Names a second distinct benefit.
- Suggests starting at a manageable level.
- Suggests warming up or following school safety rules.
- Allows rest and hydration.
- Avoids pressuring Thabo to play when unwell.
- Links the action to gradual participation.

## 1.5 · 7 marks

**Question:** 1.5 Suggest two realistic options Thabo could use to reduce late-night screen use. Give one benefit of each option, one possible difficulty with either option, and recommend one option using the scenario. [7]

**Bloom / family:** evaluate / decision_making

**Memo points (educator use):**
- Gives a first realistic option.
- Gives a second distinct realistic option.
- States one benefit of the first option.
- States one benefit of the second option.
- States one plausible difficulty with either option.
- Makes a clear recommendation.
- Justifies the recommendation using the scenario.

## Review

Confirm that the teaching sequence prepares learners for the assessment without teaching to a leaked answer key. Recheck memo accuracy and source permissions before classroom use.
