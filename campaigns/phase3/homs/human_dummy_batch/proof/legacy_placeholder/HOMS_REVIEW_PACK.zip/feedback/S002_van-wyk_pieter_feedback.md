# Draft Feedback: S002_van-wyk_pieter

Score: 0.0/30 (0.0%)

The submission provides a basic stance on school gardens but lacks depth, evidence, and structured academic writing. Further development is needed to meet the rubric expectations.

## Criteria
- Argument and focus: 0.0/10.0 - 
- Evidence and source use: 0.0/10.0 - 
- Structure and academic communication: 0.0/10.0 - 

## Boundary
Draft marking support only. Educator review and approval remain required.
