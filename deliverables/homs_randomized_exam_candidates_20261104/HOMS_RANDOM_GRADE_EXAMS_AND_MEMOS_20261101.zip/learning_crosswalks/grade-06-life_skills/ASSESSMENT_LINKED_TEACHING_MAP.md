# HOMS Learning Studio · Exam-linked teaching map

> Generated from the same source-bound, educator-review-required spine as the exam. Draft planning aid only; question-level CAPS clause mapping is not asserted.

**Subject:** Life Skills  
**Grade / phase:** 6 / intermediate_grade_4_6  
**Term:** Unspecified  
**Bloom targets:** apply, evaluate, understand

## Learning sequence anchored to the assessment

| Exam item | Prompt | Marks | Bloom / question type | Teaching use |
|---|---|---:|---|---|
| 1.1 | 1.1 Identify Thabo’s late-night habit and the activity he has stopped joining. State one effect in class and explain how his habit may contribute to it. [5] | 5 | understand / scenario_analysis | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.2 | 1.2 Suggest a realistic evening plan with a time for homework, a screen-free period before bed and one sleep-preparation activity. Put the activities in a sensible order and explain how the plan could support rest. [5] | 5 | apply / planning | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.3 | 1.3 What could Thabo say to his friend? Write a respectful I-statement that names how he feels and why, asks for specific support, and names a trusted adult he could approach if the problem continues. Explain why asking for support is responsible. [6] | 6 | apply / communication | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.4 | 1.4 Give two benefits of regular physical activity. Then suggest safe steps for Thabo's gradual return to football, including how to prepare, when to rest, and what to do if he feels unwell. [7] | 7 | understand / wellbeing | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.5 | 1.5 Suggest two realistic options Thabo could use to reduce late-night screen use. Give one benefit of each option, one possible difficulty with either option, and recommend one option using the scenario. [7] | 7 | evaluate / decision_making | Use as a retrieval check; teach prerequisite concepts before re-attempt. |

## Sources and visuals

- CAPS: Life Skills · SHA-256 `4113b006498494cd90bc5203c88ca2d5a1a1856c42b0274a31cc3f1442412317`

## Educator-only memo bridge

The matching memo remains a separate teacher artifact. Use it to build worked examples and misconception checks; do not place the memo in the learner-facing exam copy.

## Release gate

Subject expert verifies curriculum fit, source rights, answer accuracy, visual legibility, accessibility and classroom suitability before release.
