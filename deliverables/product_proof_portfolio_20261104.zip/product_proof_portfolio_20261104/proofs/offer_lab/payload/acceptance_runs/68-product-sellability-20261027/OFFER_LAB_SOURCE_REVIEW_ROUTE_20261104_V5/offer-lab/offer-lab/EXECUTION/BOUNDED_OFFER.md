# Pilot hypothesis: controlled evidence-review pack generation

**For testing, not validated demand.**

one workflow, one evidence pack, one human review cycle

## Buyer hypothesis

compliance managers at 50-250 employee firms

## Required inputs

- customer-selected workflow
- customer-owned evidence files
- review criteria or obligations where available

## Price test options (ZAR; not validated)

No numeric options supplied. No prices have been invented.

## Offer validation sequence

### 1. Problem interview

Ask target buyers to describe their current workflow, last completed example, time/cost and failure points before showing the offer.

Measures: buyer role and firm profile; recent observed workflow; current workaround and cost evidence

Interpretation: Qualitative discovery only; expressions of interest are not demand proof.

### 2. Bounded sample review

one workflow, one evidence pack, one human review cycle

Measures: source-linked claims; gaps and contradictions preserved; reviewer changes and reasons; turnaround time

Interpretation: Pilot acceptance is not compliance certification or professional approval.

### 3. Commercial test

Before quoting, obtain owner-approved delivery costs and scope. In exploratory interviews ask an open-ended willingness-to-pay question without presenting an invented price; then record actual paid pilot conversion separately from stated intent.

Measures: owner-approved quote presented; decision and objection recorded; paid conversion recorded separately

Interpretation: Only an observed paid transaction counts as payment evidence; do not infer willingness to pay from survey responses.

## Source trace

- R-01 — customer-packet://SOURCES/02_evidence_register.csv#R-01 (register SHA-256 `50be9e9a72aef9896acf1037b19371f6e032965d464a36cc12b58b944350205a`)
- R-02 — customer-packet://SOURCES/02_evidence_register.csv#R-02 (register SHA-256 `50be9e9a72aef9896acf1037b19371f6e032965d464a36cc12b58b944350205a`)
- R-03 — customer-packet://SOURCES/02_evidence_register.csv#R-03 (register SHA-256 `50be9e9a72aef9896acf1037b19371f6e032965d464a36cc12b58b944350205a`)
- R-04 — customer-packet://SOURCES/02_evidence_register.csv#R-04 (register SHA-256 `50be9e9a72aef9896acf1037b19371f6e032965d464a36cc12b58b944350205a`)

## Customer review

Use `OFFER_REVIEW.html` to record one decision, reviewer identity and role, timezone-aware review time, and rationale for each source-bound offer component. The completed CSV carries exact customer statements and source locators. Validate it with `OFFER_REVIEW_VALIDATOR.py` against `BOUNDED_OFFER.json` and `../CUSTOMER_PACKET/SOURCES/02_evidence_register.csv`. Blank or invalid reviews leave the hypothesis unapproved. A valid review receipt records owner input only; it does not prove demand, payment, professional suitability, or release authority. The supplied blank worksheet is expected to validate as `REVIEW_INCOMPLETE_OR_HOLD_REQUIRED`.


## Customer constraints

- Capability proof: controlled evidence-review pack generation.
- Target hypothesis: compliance managers at 50-250 employee firms.
- Pilot scope: one workflow, one evidence pack, one human review cycle.
- No customer payment for this offer has yet been observed.

## Allowed bounded claims

- Customer-declared capability for testing: controlled evidence-review pack generation
- human authority and external release remain explicit

## Outputs

- source-bound evidence map
- gap/contradiction register
- review-ready pack
- proof receipt

## Claim boundary

- DO NOT CLAIM: customers want this
- DO NOT CLAIM: willingness to pay is proven
- DO NOT CLAIM: the pack certifies compliance
- DO NOT CLAIM: DIO replaces professional judgement
