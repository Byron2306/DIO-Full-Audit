# Customer dossier working paper

Signed agreement is dated 3 February 2026.

Amendment draft dated 18 April 2026 is unsigned.

A payment spreadsheet lists R426,000 outstanding.

An email claims the amendment was 'agreed in principle' but no signed amendment is supplied.

## Packet-bound source records

- amendment_draft_2026-04-18.md — SHA-256 `4f00c3edea47cf378e615a5949d7fc8d9850503e5f1c20f29a92e5114c563594`
- amendment_email.eml — SHA-256 `485ab7a2c92f4e7b7961bcc147c788d052a084386f01e5ebeba621254099ae50`
- payment_schedule.csv — SHA-256 `e4d17fe9b9569aef46a90b4ac15a67086453443c4fdee453172ae3f204fd4d64`
- signed_agreement_extract.md — SHA-256 `b1e009f515f76a00e8a30f35c75748ae7be35ab3a9b534eab194f41677665d71`

## Exception retained

DossierOps must distinguish signed records from drafts and cannot give legal conclusions about enforceability.
