> Draft educator aid: verify every suggested teaching use and CAPS scope before classroom use.

# HOMS Educator · Exam to Learning Crosswalk

**English Language · Grade 9 · Term unspecified**

This educator-only file maps the generated memo to teach-back and misconception checks. The learner guide receives prompts only; keep this file and the memorandum with educators.

## 1.1 · 6 marks

**Question:** 1.1 Name three services the van offers and state where it stops each Thursday. [6]

**Bloom / family:** remember / literal_comprehension

**Memo points (educator use):**
- Names the book or newspaper lending service.
- Names the tablet reading activities.
- Names help with online forms.
- States that the van stops beside Mhlabeni Community Hall.
- States that the van stops there every Thursday.
- Presents the information clearly and accurately using passage details.

## 1.2 · 7 marks

**Question:** 1.2 Explain why the service records borrowed books and uses offline tablets. [7]

**Bloom / family:** understand / inference

**Memo points (educator use):**
- Links borrowing records to identifying popular titles.
- Links popular titles to future stock choices.
- States offline tablets work without a mobile signal.
- Explains how this helps learners in a weak-signal area.
- Uses evidence from the passage.
- Keeps the two reasons distinct.
- Writes a logical explanation.

## 1.3 · 8 marks

**Question:** 1.3 What does Naledi mean when she says residents help shape the route? [8]

**Bloom / family:** analyze / interpretation

**Memo points (educator use):**
- Identifies the monthly meeting as a way to give suggestions.
- Explains that suggestions influence where the van stops.
- Connects route choice to community needs.
- Uses the passage rather than an unsupported assumption.
- Distinguishes consultation from guaranteed weekly service.
- Gives one relevant example from the text.
- Writes in own words.
- Makes the meaning clear.

## 1.4 · 9 marks

**Question:** 1.4 Rewrite 'The tablets work offline, so learners can use them even when the mobile signal is weak' as two sentences without changing its meaning. Preserve both facts and their cause-and-effect link; check grammar, capitals and punctuation, and do not add a new claim. [9]

**Bloom / family:** apply / language_editing

**Memo points (educator use):**
- Produces two complete sentences.
- Keeps the fact that tablets work offline.
- Keeps the fact that learners can use them.
- Keeps the weak-signal condition.
- Uses an appropriate linking or explanatory phrase.
- Uses capitals correctly.
- Uses end punctuation correctly.
- Maintains grammatical agreement.
- Does not add a new claim.

## 1.5 · 10 marks

**Question:** 1.5 In a short paragraph, evaluate one strength and one limitation of the travelling library service. [10]

**Bloom / family:** evaluate / paragraph_response

**Memo points (educator use):**
- Identifies a supported strength.
- Explains who benefits from it.
- Identifies the limitation that it cannot visit every street weekly.
- Explains the effect of the limitation.
- Uses one piece of textual evidence for the strength.
- Uses one piece of textual evidence for the limitation.
- Makes a balanced judgment.
- Uses a coherent paragraph structure.
- Uses appropriate vocabulary.
- Maintains a clear conclusion.

## Review

Confirm that the teaching sequence prepares learners for the assessment without teaching to a leaked answer key. Recheck memo accuracy and source permissions before classroom use.
