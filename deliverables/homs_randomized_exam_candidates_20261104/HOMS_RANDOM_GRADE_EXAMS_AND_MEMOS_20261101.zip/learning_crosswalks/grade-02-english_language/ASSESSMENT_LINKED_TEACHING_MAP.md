# HOMS Learning Studio · Exam-linked teaching map

> Generated from the same source-bound, educator-review-required spine as the exam. Draft planning aid only; question-level CAPS clause mapping is not asserted.

**Subject:** English Language  
**Grade / phase:** 2 / foundation_grade_r_3  
**Term:** Unspecified  
**Bloom targets:** apply, remember, understand

## Learning sequence anchored to the assessment

| Exam item | Prompt | Marks | Bloom / question type | Teaching use |
|---|---|---:|---|---|
| 1.1 | 1.1 When and where did Class Two plant the bean seeds? What did Asha put by each pot? [4] | 4 | remember / retrieve_specific_details | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.2 | 1.2 Name two things the class did to help the seeds grow. What did they use to measure the shoots, and when did two shoots appear? [4] | 4 | understand / retrieve_multiple_details | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.3 | 1.3 Give two reasons the class watered the pots only when the soil felt dry. Explain how this helped save water and keep the plants healthy. [4] | 4 | understand / infer_reason | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.4 | 1.4 Change this sentence to describe one pot: 'The pots are near a sunny window.' [4] | 4 | apply / language_structures | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.5 | 1.5 Write two sentences about how you would care for a class plant. [4] | 4 | apply / short_composition | Use as a retrieval check; teach prerequisite concepts before re-attempt. |

## Sources and visuals

- CAPS: English · SHA-256 `db09b7292552ef6b374a76ff473eb719eee367f3bb3c8eb788f21bae2ad1ad5e`

## Educator-only memo bridge

The matching memo remains a separate teacher artifact. Use it to build worked examples and misconception checks; do not place the memo in the learner-facing exam copy.

## Release gate

Subject expert verifies curriculum fit, source rights, answer accuracy, visual legibility, accessibility and classroom suitability before release.
