# Mobile Care for Moya Clinic operations committee · vertical short

Story hash: `sha256:fbaa35fa57c8687ee0a2d85bd1285aeccc356708701d4ae91bcba13178a63568`
Semantic law: `sha256:1ea601a36a5743de2b4679945061bd8ce20ffcb8d1c4e7b3049b8cbf10572b0c`
Projection: `sha256:d08257503b419c895116c8a0991a6420b5daf0dc7163078254c4056082d7a1a6`
Arc family: `problem_to_proof`

## 1. Start with the real job

**Role:** hook

For Moya Clinic operations committee, the immediate friction is monthly site reports are split across five clinic spreadsheets.

Visual direction: Open with one concrete working moment and no architecture language.

## 2. Name what keeps repeating

**Role:** pain

The recurring cost is not only the task itself. It is the repeated effort needed to reconstruct context, check the work and prepare something another person can safely review.

Visual direction: Use a second, distinct working moment so the problem develops instead of repeating the hook.

## 3. Show the useful change

**Role:** workflow

Mobile Care is used to provide scheduled primary-care appointments at five community sites. The bounded result is one monthly view of scheduled and completed appointments.

Visual direction: Show supplied material moving into a bounded review state with the handoff visible.

## 4. Put proof on screen

**Role:** proof

The claim has to survive inspection: the September service log records 240 completed appointments.

Visual direction: Use the real proof object, source trail or product surface rather than a fictional success metric.

## 5. The human still decides

**Role:** human_gate

The system prepares a bounded review state; the authorised human keeps judgement and release.

Visual direction: Make the human review or release point the visual anchor instead of a legal-disclaimer card.

## 6. Keep the next step small

**Role:** cta

The next step is request the next-quarter schedule.

Visual direction: Close on one concrete action with no urgency fiction or automatic-release implication.

## Semantic boundary

Creative form may change. Meaning, proof boundaries, human authority, publication hold, spend disablement and market-validation boundary may not.
