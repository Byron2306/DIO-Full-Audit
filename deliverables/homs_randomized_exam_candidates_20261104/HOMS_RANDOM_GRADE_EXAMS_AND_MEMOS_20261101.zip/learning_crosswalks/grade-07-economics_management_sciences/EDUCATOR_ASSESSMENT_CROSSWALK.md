> Draft educator aid: verify every suggested teaching use and CAPS scope before classroom use.

# HOMS Educator · Exam to Learning Crosswalk

**Economic and Management Sciences · Grade 7 · Term unspecified**

This educator-only file maps the generated memo to teach-back and misconception checks. The learner guide receives prompts only; keep this file and the memorandum with educators.

## 1.1 · 6 marks

**Question:** 1.1 For each item, say whether it is used to make the fruit cups, is a business expense, or both. Explain your choices for the fruit and the table fee. [6]

**Bloom / family:** understand / business_concepts

**Memo points (educator use):**
- Identifies fruit as a material used to make the fruit cups. The R90 purchase is also a business expense. (Accept both roles.)
- Identifies the table fee as a business expense.
- Explains that fruit is used in the product being made.
- Explains that the table fee pays for selling space at the market.
- Distinguishes a production input from sales revenue.
- Recognises that one item can be both a production input and an expense; the categories are not mutually exclusive.

## 1.2 · 6 marks

**Question:** 1.2 Calculate revenue from the cups sold. [6]

**Bloom / family:** apply / calculation

**Memo points (educator use):**
- Identifies 24 cups sold.
- Identifies selling price R12 per cup.
- Uses 24 x R12.
- Calculates 20 x 12 = R240 or equivalent.
- Calculates 4 x 12 = R48 or equivalent.
- Gives revenue R288.

## 1.3 · 8 marks

**Question:** 1.3 Calculate sales revenue and the cash remaining after the stated outlays. Explain why that cash balance alone does not establish profit. [8]

**Bloom / family:** apply / budget

**Memo points (educator use):**
- Calculates cup cost: 30 x R4 = R120.
- Identifies fruit cost R90.
- Identifies table fee R30.
- Adds the three outlays to get R240.
- Calculates sales revenue as 24 x R12 = R288.
- Subtracts stated outlays from revenue.
- Gives R48 cash remaining after those outlays.
- Notes that six cups remain unsold, so inventory value/cost treatment is needed to establish accounting profit.

## 1.4 · 10 marks

**Question:** 1.4 Explain two reasons the six unsold cups matter for the next market day. Use case facts to recommend how many cups to make or buy, and address freshness or safety, waste, and why unsold stock is not sales revenue. [10]

**Bloom / family:** analyze / inventory_planning

**Memo points (educator use):**
- States unsold cups represent stock not sold.
- Notes that ingredients or cups may have cost money.
- Explains that demand may be lower than expected.
- Suggests adjusting quantity made or bought.
- Uses one relevant scenario figure.
- Recognises food freshness/safety constraints.
- Avoids counting unsold cups as sales revenue.
- Gives a second distinct planning reason.
- Connects planning to reducing waste or cost.
- Writes a supported explanation.

## 1.5 · 10 marks

**Question:** 1.5 Recommend one change for Lebo's next market day and support it with two calculations or facts from the case. [10]

**Bloom / family:** evaluate / recommendation

**Memo points (educator use):**
- States one realistic change.
- Uses the 24 cups sold as evidence.
- Uses the 6 unsold cups as evidence.
- Calculates or cites revenue of R288.
- Calculates or cites the stated costs of R240.
- Shows a correct comparison or inference.
- Explains how the change may improve planning.
- Considers customer demand.
- Keeps the recommendation within the information provided.
- Presents a clear supported conclusion.

## Review

Confirm that the teaching sequence prepares learners for the assessment without teaching to a leaked answer key. Recheck memo accuracy and source permissions before classroom use.
