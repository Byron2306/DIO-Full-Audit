# Accessible Publish · owner remediation request

This checklist turns detected source issues into concrete questions. It does not guess image meaning, declare conformance, or authorize release.

## OWNER-001 · aria_labelledby_reference

**Finding:** Form control broken has aria-labelledby that does not resolve to detected non-empty text (missing IDs: missing-label). Static text check only; verify the computed name with assistive technology.

**Owner action:** Point aria-labelledby to an element with meaningful text, or provide the correct owner-approved label. The static check only measures descendant text; verify the resulting accessible name with assistive technology.

**Reply format:** `source_reference_or_label`

**State:** Needs owner input.

## OWNER-002 · form_control_name

**Finding:** Form control broken has no detected label.

**Owner action:** Review this finding and provide the correction or an explicit no-change decision.

**Reply format:** `owner_decision`

**State:** Needs owner input.

## OWNER-003 · link_purpose

**Finding:** Link to /documents has no detected accessible name.

**Owner action:** Supply link text that describes the destination and confirm that the target is correct.

**Reply format:** `label_and_target`

**State:** Needs owner input.

## OWNER-004 · rendered_text_contrast

**Finding:** 4 rendered text run(s) across 4 viewports fall below the applicable contrast ratio.

**Owner action:** Review this finding and provide the correction or an explicit no-change decision.

**Reply format:** `owner_decision`

**State:** Needs owner input.

## OWNER-005 · keyboard_focus_visibility

**Finding:** 4 tab stop(s) had no visible focus indicator in the browser render.

**Owner action:** Review this finding and provide the correction or an explicit no-change decision.

**Reply format:** `owner_decision`

**State:** Needs owner input.

## OWNER-006 · scripted_keyboard_focus_visibility

**Finding:** 8 scripted tab stop(s) lacked a visible focus indicator.

**Owner action:** Review this finding and provide the correction or an explicit no-change decision.

**Reply format:** `owner_decision`

**State:** Needs owner input.

Publication remains held pending owner and accessibility review.
