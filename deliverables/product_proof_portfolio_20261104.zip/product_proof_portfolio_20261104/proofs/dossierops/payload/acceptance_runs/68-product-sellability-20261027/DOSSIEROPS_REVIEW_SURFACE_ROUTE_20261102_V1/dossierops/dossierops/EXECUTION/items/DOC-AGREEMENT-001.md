# Customer-supplied signed agreement extract

Record ID: DOC-AGREEMENT-001
Status declared by customer: signed
Agreement date: 3 February 2026

This synthetic extract contains only the customer-declared date and status. It is not a complete agreement and authenticity has not been independently verified.
