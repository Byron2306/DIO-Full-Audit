# HOMS Learning Studio · Exam-linked teaching map

> Generated from the same source-bound, educator-review-required spine as the exam. Draft planning aid only; question-level CAPS clause mapping is not asserted.

**Subject:** English Language  
**Grade / phase:** 9 / senior_grade_7_9  
**Term:** Unspecified  
**Bloom targets:** analyze, apply, evaluate, remember, understand

## Learning sequence anchored to the assessment

| Exam item | Prompt | Marks | Bloom / question type | Teaching use |
|---|---|---:|---|---|
| 1.1 | 1.1 Name three services the van offers and state where it stops each Thursday. [6] | 6 | remember / literal_comprehension | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.2 | 1.2 Explain why the service records borrowed books and uses offline tablets. [7] | 7 | understand / inference | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.3 | 1.3 What does Naledi mean when she says residents help shape the route? [8] | 8 | analyze / interpretation | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.4 | 1.4 Rewrite 'The tablets work offline, so learners can use them even when the mobile signal is weak' as two sentences without changing its meaning. Preserve both facts and their cause-and-effect link; check grammar, capitals and punctuation, and do not add a new claim. [9] | 9 | apply / language_editing | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.5 | 1.5 In a short paragraph, evaluate one strength and one limitation of the travelling library service. [10] | 10 | evaluate / paragraph_response | Use as a retrieval check; teach prerequisite concepts before re-attempt. |

## Sources and visuals

- CAPS: English · SHA-256 `489f8c6076c86f5515df3ec00ce5cb8aa403435e28215d8423c7e42855c56a49`

## Educator-only memo bridge

The matching memo remains a separate teacher artifact. Use it to build worked examples and misconception checks; do not place the memo in the learner-facing exam copy.

## Release gate

Subject expert verifies curriculum fit, source rights, answer accuracy, visual legibility, accessibility and classroom suitability before release.
