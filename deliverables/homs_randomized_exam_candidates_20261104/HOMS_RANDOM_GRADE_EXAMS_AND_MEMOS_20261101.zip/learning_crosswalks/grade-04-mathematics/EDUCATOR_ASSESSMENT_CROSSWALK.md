> Draft educator aid: verify every suggested teaching use and CAPS scope before classroom use.

# HOMS Educator · Exam to Learning Crosswalk

**Mathematics · Grade 4 · Term unspecified**

This educator-only file maps the generated memo to teach-back and misconception checks. The learner guide receives prompts only; keep this file and the memorandum with educators.

## 1.1 · 5 marks

**Question:** 1.1 Calculate the total number of seedlings. Show a method. [5]

**Bloom / family:** apply / multiplication

**Memo points (educator use):**
- Recognises 8 equal groups of 24.
- Uses multiplication or repeated addition.
- Calculates 8 x 20 = 160 or equivalent.
- Calculates 8 x 4 = 32 or equivalent.
- Adds to give 192 seedlings.

## 1.2 · 5 marks

**Question:** 1.2 Learners measured the garden’s four sides with a tape: 8 m, 5 m, 8 m and 5 m. Add the four measurements to find the perimeter. [5]

**Bloom / family:** apply / perimeter

**Memo points (educator use):**
- Identifies the four measured side lengths as 8 m, 5 m, 8 m and 5 m.
- Chooses to add all four side measurements to find the perimeter.
- Adds the two 8 m sides to get 16 m.
- Adds the two 5 m sides to get 10 m.
- Adds the side totals to get 26 m and includes the unit.

## 1.3 · 6 marks

**Question:** 1.3 What fraction of the 192 seedlings is 48? Simplify it. Show how you simplify the fraction and check your answer. [6]

**Bloom / family:** understand / fraction

**Memo points (educator use):**
- Writes the fraction 48/192.
- Identifies 48 as a common divisor of 48 and 192, or shows another valid common-divisor method.
- Shows the numerator divided by the chosen common divisor, for example 48 ÷ 48 = 1 or 48 ÷ 16 = 3.
- Shows the denominator divided by the same common divisor, for example 192 ÷ 48 = 4 or 192 ÷ 16 = 12.
- Gives the simplified fraction 1/4.
- Checks the result by showing that 1/4 of 192 is 48.

## 1.4 · 7 marks

**Question:** 1.4 The class has 360 seeds and plants 145. Show the column subtraction, make any regrouping clear, and check your answer with addition. How many seeds remain? [7]

**Bloom / family:** apply / subtraction

**Memo points (educator use):**
- Chooses subtraction and writes 360 - 145.
- Shows the regrouping needed to subtract the ones correctly.
- Subtracts the ones correctly.
- Subtracts the tens correctly.
- Subtracts the hundreds correctly.
- Gives 215 seeds remaining.
- Checks the result with addition, for example 215 + 145 = 360.

## 1.5 · 6 marks

**Question:** 1.5 Each seedling needs 250 mL of water. For 8 seedlings, show the multiplication and the conversion calculation. Give the total in millilitres and litres. [6]

**Bloom / family:** apply / measurement_conversion

**Memo points (educator use):**
- Sets up 8 groups of 250 mL, for example 250 × 8.
- Calculates 2,000 mL.
- Uses the relationship 1,000 mL = 1 L.
- Shows division by 1,000 or an equivalent conversion method.
- Gives the converted answer as 2 L.
- Includes the correct mL and L units with the two totals.

## Review

Confirm that the teaching sequence prepares learners for the assessment without teaching to a leaked answer key. Recheck memo accuracy and source permissions before classroom use.
