# HOMS Learning Studio · Exam-linked teaching map

> Generated from the same source-bound, educator-review-required spine as the exam. Draft planning aid only; question-level CAPS clause mapping is not asserted.

**Subject:** Mathematics  
**Grade / phase:** 4 / intermediate_grade_4_6  
**Term:** Unspecified  
**Bloom targets:** apply, understand

## Learning sequence anchored to the assessment

| Exam item | Prompt | Marks | Bloom / question type | Teaching use |
|---|---|---:|---|---|
| 1.1 | 1.1 Calculate the total number of seedlings. Show a method. [5] | 5 | apply / multiplication | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.2 | 1.2 Learners measured the garden’s four sides with a tape: 8 m, 5 m, 8 m and 5 m. Add the four measurements to find the perimeter. [5] | 5 | apply / perimeter | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.3 | 1.3 What fraction of the 192 seedlings is 48? Simplify it. Show how you simplify the fraction and check your answer. [6] | 6 | understand / fraction | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.4 | 1.4 The class has 360 seeds and plants 145. Show the column subtraction, make any regrouping clear, and check your answer with addition. How many seeds remain? [7] | 7 | apply / subtraction | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.5 | 1.5 Each seedling needs 250 mL of water. For 8 seedlings, show the multiplication and the conversion calculation. Give the total in millilitres and litres. [6] | 6 | apply / measurement_conversion | Use as a retrieval check; teach prerequisite concepts before re-attempt. |

## Sources and visuals

- CAPS: Mathematics · SHA-256 `7fec668a6d3b0ed4ae6974a9739970a2128a80553589f682ff5d5bffc02a783e`

## Educator-only memo bridge

The matching memo remains a separate teacher artifact. Use it to build worked examples and misconception checks; do not place the memo in the learner-facing exam copy.

## Release gate

Subject expert verifies curriculum fit, source rights, answer accuracy, visual legibility, accessibility and classroom suitability before release.
