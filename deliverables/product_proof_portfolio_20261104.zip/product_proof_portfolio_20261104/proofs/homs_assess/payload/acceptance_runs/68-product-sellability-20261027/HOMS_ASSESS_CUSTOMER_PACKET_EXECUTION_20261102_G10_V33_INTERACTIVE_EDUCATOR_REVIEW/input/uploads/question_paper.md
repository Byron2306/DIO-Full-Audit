Grade 10 Physical Sciences: Motion in one dimension

Total: 50 marks

Assessment
A trolley moves directly east along a straight track without reversing direction. Take east as the positive direction. It starts at position x = -4 m and reaches x = +20 m in 6 s. Later, its velocity changes from +3 m·s⁻¹ to +15 m·s⁻¹ in 4 s. Assume uniform motion during each stated interval.

1.1. Distinguish distance and displacement, then calculate both for the first movement. [8 marks]
1.2. Calculate the trolley's average velocity for the first interval. [9 marks]
1.3. Calculate acceleration during the later interval and state what its sign means. [10 marks]
1.4. If the later acceleration stays constant for 3 more seconds, calculate the new velocity. [11 marks]
1.5. Explain how a position-time graph and a velocity-time graph show motion differently. [12 marks]
