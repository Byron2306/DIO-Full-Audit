# HOMS Learning Studio · Exam-linked teaching map

> Generated from the same source-bound, educator-review-required spine as the exam. Draft planning aid only; question-level CAPS clause mapping is not asserted.

**Subject:** Life Orientation  
**Grade / phase:** 8 / senior_grade_7_9  
**Term:** Unspecified  
**Bloom targets:** analyze, apply, evaluate, understand

## Learning sequence anchored to the assessment

| Exam item | Prompt | Marks | Bloom / question type | Teaching use |
|---|---|---:|---|---|
| 1.1 | 1.1 Explain how pressure from a friend could affect the learner’s confidence in their own ability. Write one positive self-talk statement and give one action that would help the learner use their own ability on the assignment. [6] | 6 | understand / scenario_analysis | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.2 | 1.2 Create a two-week plan with three milestones and one leisure period. [6] | 6 | apply / planning | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.3 | 1.3 Compare asking the teacher for help with copying a classmate's work. [8] | 8 | analyze / comparison | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.4 | 1.4 Write a respectful message to a friend explaining a boundary about copying while preserving the friendship. [10] | 10 | apply / transactional_writing | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.5 | 1.5 Recommend one help-seeking step and explain how the learner can monitor progress. [10] | 10 | evaluate / help_seeking | Use as a retrieval check; teach prerequisite concepts before re-attempt. |

## Sources and visuals

- CAPS: Life Orientation · SHA-256 `7904a388b6dfda1c3b265638d7f91298e2290e50eda65f9625fa3a764356dca3`

## Educator-only memo bridge

The matching memo remains a separate teacher artifact. Use it to build worked examples and misconception checks; do not place the memo in the learner-facing exam copy.

## Release gate

Subject expert verifies curriculum fit, source rights, answer accuracy, visual legibility, accessibility and classroom suitability before release.
