# DIO Product Proof Portfolio

This package selects one strongest available customer-facing artifact for each of the 68 catalog offers and includes its product-specific receipt or evidence record when present. Open `index.html` for the review surface; `PRODUCT_PROOF_INDEX.json` and `.csv` provide exact source paths and SHA-256 hashes.

## Evidence boundary

- Snapshot generated: `2026-11-04T15:24:48+00:00`; evidence date: `2026-11-04`. Deliverable references dated after that snapshot were excluded (5 refs); products without an in-window customer deliverable use a clearly marked historical baseline artifact.
- The artifacts are controlled examples and held review material. **They are not professional certifications, customer acceptance, verified source truth, commercial validation, or release authorization.**
- The current qualification snapshot records 0/68 independent professional sign-offs and 0 release authorizations.
- Product-specific limitations are retained in each portfolio record and the index. Sonoris, Pictora and Dicere media candidates are included as a separate appendix because they are creative organs, not catalog offers.
- HOMS Exam links to the saved randomized Grades 1–12 exam and memo candidate bundle. Those exams remain drafts requiring educator moderation; Grade 12 is a 50-mark focused assessment, not a full Grade 12 CAPS examination.

## Selection and integrity

Selection is deterministic and based on the current qualification snapshot's `customer_deliverable_refs`, with PDF preferred, followed by editable office files, HTML and other formats. HOMS Exam uses the saved Grades 1–12 candidate ZIP. Local HTML dependencies are copied when referenced. Every copied output and route receipt has a SHA-256 hash in the manifest. Hash verification establishes byte identity only, not content correctness.
