> Draft educator aid: verify every suggested teaching use and CAPS scope before classroom use.

# HOMS Educator · Exam to Learning Crosswalk

**Natural Sciences and Technology · Grade 5 · Term unspecified**

This educator-only file maps the generated memo to teach-back and misconception checks. The learner guide receives prompts only; keep this file and the memorandum with educators.

## 1.1 · 5 marks

**Question:** 1.1 Name the four materials mixed in the example and name the processed material they make. [5]

**Bloom / family:** remember / materials_and_products

**Memo points (educator use):**
- Names sand.
- Names gravel.
- Names cement.
- Names water.
- Names concrete as the processed material.

## 1.2 · 5 marks

**Question:** 1.2 State what property information learners should record before mixing and after the samples set. Give two examples of properties to compare and explain why they record both stages. [5]

**Bloom / family:** understand / observation

**Memo points (educator use):**
- Records properties of the starting materials before mixing.
- Names appearance as one observable property.
- Names texture or another valid observable property as a second property.
- Records a property of the set concrete, such as strength or durability.
- Explains that comparing before and after shows how processing changes material properties.

## 1.3 · 6 marks

**Question:** 1.3 In the two-sample test, identify what is changed, what is measured and three conditions that should be kept the same. Explain why this makes the comparison fair. [6]

**Bloom / family:** analyze / fair_test

**Memo points (educator use):**
- Identifies amount of gravel as the changed factor.
- Identifies the number of identical counters supported before cracking as the measured result.
- Keeps the amount of sand the same.
- Keeps the amount of cement and water the same.
- Keeps the mould and setting time the same.
- Explains that changing only the gravel amount helps make the comparison fair.

## 1.4 · 7 marks

**Question:** 1.4 Based on the planned test, predict which sample will support more counters, or predict that they will support the same number. Explain why your prediction is reasonable, state what result will count as evidence, and give one reason the result should be checked with repeated trials. [7]

**Bloom / family:** evaluate / prediction

**Memo points (educator use):**
- Gives a clear prediction, including a reasoned prediction of no difference.
- Links the prediction to the changed gravel amount without claiming the result is certain.
- Identifies the number of counters supported before cracking as the result to observe.
- Explains that the same counter type and test method allow comparison.
- Recognises that individual small samples may give unusual results.
- Explains that repeated trials help check whether a result is consistent.
- States that the conclusion should be based on recorded results.

## 1.5 · 7 marks

**Question:** 1.5 Give suitable results-table headings, including units where needed, for the gravel test. Then describe one way to keep the comparison reliable and one limitation of using small samples to choose material for a real path. [7]

**Bloom / family:** evaluate / data_handling

**Memo points (educator use):**
- Includes a sample or gravel-condition heading.
- Includes the gravel amount with a stated unit or defined measure.
- Includes a trial number.
- Includes the number of counters supported before cracking.
- Keeps other ingredients, mould and setting time the same.
- Repeats the test and records results consistently.
- Notes that small samples cannot by themselves prove how a full path will perform.

## Review

Confirm that the teaching sequence prepares learners for the assessment without teaching to a leaked answer key. Recheck memo accuracy and source permissions before classroom use.
