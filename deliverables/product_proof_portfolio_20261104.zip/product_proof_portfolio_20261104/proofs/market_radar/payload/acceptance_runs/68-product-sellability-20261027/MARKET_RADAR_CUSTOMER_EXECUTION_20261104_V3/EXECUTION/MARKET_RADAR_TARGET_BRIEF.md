# Market Radar — source-bound signal brief

**Scope:** South Africa · 20-200 person professional-services firms
**Captured:** 2026-11-04T11:51:10+00:00

This is a small public-signal sample. It does not prove demand, market size, willingness to pay, competitive rank or product-market fit.

## ZA-COMPLY-001 — AstriComply | Guided POPIA Compliance Software for South African Businesses

- Publisher/source: https://astricomply.co.za/
- Category: vendor_product_and_pricing · POPIA workflow and compliance evidence software
- Capture: 2026-11-04T11:51:10+00:00 · 142302 bytes · SHA-256 `123e164686ebe562cc399e803374bf3b0692c321a91bb603d012786cdcfe4a2e`
- Published price signal: Standard — R149/month. Vendor-published price at capture time; verify tax, promotional terms, user limits and inclusions directly.
- Published price signal: Business — R299/month. Vendor-published price at capture time; verify tax, promotional terms, user limits and inclusions directly.
- Published price signal: Agency — R995/month. Vendor-published price at capture time; verify tax, promotional terms, user limits and inclusions directly.
- Vendor feature claim: Vendor describes an evidence-vault feature.
- Vendor feature claim: Vendor describes a processing-register feature.
- Vendor feature claim: Vendor describes a service-provider register feature.
- Vendor feature claim: Vendor describes recurring review reminders.
- Scope limit: Vendor's own offer and list prices; not a market-size or demand measure.

## ZA-FILESAFE-001 — Pricing - FileSafe

- Publisher/source: https://filesafe.co.za/pricing/
- Category: vendor_product_and_pricing · Law-firm case and document management software
- Capture: 2026-11-04T11:51:10+00:00 · 56284 bytes · SHA-256 `6b6f51181db41f3cada36b87787614a5c36a577cc223d5f12408475d03274758`
- Published price signal: Solo Firm — R789/month. Vendor-published price at capture time; verify tax, promotional terms, user limits and inclusions directly.
- Published price signal: Small Firm — R1,479/month. Vendor-published price at capture time; verify tax, promotional terms, user limits and inclusions directly.
- Published price signal: Med-Large Firm — R2,169/month. Vendor-published price at capture time; verify tax, promotional terms, user limits and inclusions directly.
- Vendor feature claim: Vendor describes case-management functionality.
- Vendor feature claim: Vendor describes document-management functionality.
- Vendor feature claim: Vendor describes case-workflow automation.
- Scope limit: Adjacent legal-practice workflow; not a direct like-for-like offer.

## ZA-CAPECOM-001 — Key Findings of the Cape Chamber Business Environment Survey | Cape Chamber of Commerce & Industry

- Publisher/source: https://capechamber.co.za/media-release/key-findings-cape-chamber-business-environment-survey
- Category: business_survey · Reported South African business constraints and compliance burden
- Capture: 2026-11-04T11:51:10+00:00 · 143103 bytes · SHA-256 `ca568582cebf7b0325b7475835a5d92f617901524cbefbc7b112678f9cced578`
- Context signal: Survey sample size reported by the publisher; not a representative estimate for the target segment.
- Context signal: Publisher reports a predominantly Western Cape sample; avoid treating the finding as nationally representative.
- Context signal: Publisher-reported labour-regulation constraint among the largest-employer subgroup; not evidence about 20–200 person professional firms.
- Scope limit: Chamber survey is predominantly Western Cape, mixed-sector, and not specific to the target buyer segment.

## Decision use

Use these observations to frame buyer interviews and compare testable workflows. Confirm prices and features directly with vendors before making commercial decisions. The synthetic customer case contains no buyer interviews, purchase data or willingness-to-pay evidence.
