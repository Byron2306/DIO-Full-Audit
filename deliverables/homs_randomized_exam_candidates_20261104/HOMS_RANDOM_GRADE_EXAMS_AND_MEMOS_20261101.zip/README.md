# HOMS randomized CAPS draft exam candidates · Grades 1–12

This saved candidate set contains one randomized subject assignment, draft examination and matching marking memo for each school grade. Subject selection uses seed `20261101` without repeats within each CAPS phase. Each grade folder contains editable DOCX files, the source assessment JSON and a receipt binding the paper and memo to the official CAPS PDF source.

## Candidate status

All 12 grade packs are retained as **draft candidates**. They passed HOMS Moderate's mechanical pre-moderation and have current print-ready PDFs. They have not received independent subject-educator approval and are not authorized for classroom release. The question map is a focused, source-backed scope trace; it does not claim full-year CAPS coverage.

Marks by grade: Grade 1–3: 20 each; Grade 4: 29; Grade 5–6: 30 each; Grade 7–9: 40 each; Grade 10–12: 50 each. Papers are 45 minutes for Grades 1–3, 60 minutes for Grades 4–6, 90 minutes for Grades 7–9, and 120 minutes for Grades 10–12.

## Current accuracy revisions

- **Grade 3 Mathematics:** Q1.5 now asks for a listed 2-D shape with four straight sides, aligning to the cited Grade 3 shapes page. Q1.2's memo awards consistent carry-forward quotient and remainder credit.
- **Grade 4 Mathematics:** Q1.5 asks learners to show the multiplication and millilitre-to-litre conversion its six marks assess. The grade paper total is 29. The conversion is tied to official CAPS physical page 93. The perimeter item asks for addition of tape-measured sides and does not require a formula.
- **Grade 5 Natural Sciences and Technology:** Concrete is used as the Grade 5 processing example. Rubrics distinguish before/after properties, award three controlled variables separately, and request two reliability actions where separate marks are awarded.
- **Grade 6 Life Skills:** The evening-plan, supportive-communication and screen-use comparison prompts now request the elements assessed by their memo criteria.
- **Grade 7 EMS:** Fruit is treated as both a production input and a business expense; the market table fee is a selling expense.
- **Grade 10 Physical Sciences:** Motion includes a reversal so path distance differs from displacement; both average speed and average velocity are assessed.
- **Grade 11 English:** The paper includes its source-bound survey table and asks learners to compare the reported proportions without generalizing to all learners.
- **Grade 12 Business Studies:** The focused legislation item assesses the Consumer Protection Act and ingredient-label decisions.

Correction receipts and the latest output hashes are included in the source bundle. Older correction notes remain historical and are marked or superseded where their wording no longer describes the current paper.

## Open the saved candidates and review evidence

- [Grade 1–12 candidate index](index.html)
- [Print-ready PDF manifest](PRINT_READY_PDF_MANIFEST.json)
- [All candidate exam and memo PDFs](HOMS_RANDOM_GRADE_EXAMS_AND_MEMOS_PRINT_READY_20261101.zip)
- [Editable exams, memos, source receipts and review evidence](HOMS_RANDOM_GRADE_EXAMS_AND_MEMOS_20261101.zip)
- [Question-level CAPS mappings](CAPS_QUESTION_ALIGNMENT_ALL_GRADES_20261101.json)
- [Current CAPS page-excerpt review bundle](caps_source_excerpt_reviews_20261104_v28/index.html)
- [Current visual layout audit](../../acceptance_runs/68-product-sellability-20261027/HOMS_RANDOM_GRADE_EXAM_VISUAL_RENDER_AUDIT_20261104_V15.json)
- [Educator moderation guide](HOMS_EDUCATOR_MODERATION_GUIDE.md)

The current visual audit checks all 24 PDFs and all 33 rendered pages against the print manifest. [Workflow diagram](media/homs_randomized_candidate_workflow.svg). The visual audit checks the current PDF layouts and hashes; it does not establish answer correctness or educator approval. Read each grade's CAPS excerpt and memo before using a candidate. Keep all candidates in draft status until a qualified subject educator confirms content, term fit, language, accessibility, mark demand and acceptable alternatives.
