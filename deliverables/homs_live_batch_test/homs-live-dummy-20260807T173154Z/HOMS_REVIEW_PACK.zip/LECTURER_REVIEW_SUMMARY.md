# HOMS Lecturer Review Summary

Job: `homs-live-dummy-20260807T173154Z`
Created: 2026-08-07T17:32:02+00:00
Provider: openai / gpt-4o-mini

## Batch Results
- student_alpha: 22.95/30 (76.5%)
- student_beta: 17.51/30 (58.37%)
- student_gamma: 23.11/30 (77.03%)

## Review Boundary
These are draft marking-support outputs for a controlled fake batch. Educator approval is required before final marks or feedback.

## Provider Errors
- student_alpha.txt: AuthenticationError: Error code: 401 - {'error': {'message': 'Incorrect API key provided: sk-67af2***********************d7cb. You can find your API key at https://platform.openai.com/account/api-keys.', 'type': 'invalid_request_error', 'code': 'invalid_api_key', 'param': None}, 'status': 401}
- student_beta.txt: AuthenticationError: Error code: 401 - {'error': {'message': 'Incorrect API key provided: sk-67af2***********************d7cb. You can find your API key at https://platform.openai.com/account/api-keys.', 'type': 'invalid_request_error', 'code': 'invalid_api_key', 'param': None}, 'status': 401}
- student_gamma.txt: AuthenticationError: Error code: 401 - {'error': {'message': 'Incorrect API key provided: sk-67af2***********************d7cb. You can find your API key at https://platform.openai.com/account/api-keys.', 'type': 'invalid_request_error', 'code': 'invalid_api_key', 'param': None}, 'status': 401}
