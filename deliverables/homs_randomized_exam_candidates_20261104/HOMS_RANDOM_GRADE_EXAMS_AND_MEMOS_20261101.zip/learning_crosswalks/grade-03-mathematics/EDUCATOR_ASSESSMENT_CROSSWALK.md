> Draft educator aid: verify every suggested teaching use and CAPS scope before classroom use.

# HOMS Educator · Exam to Learning Crosswalk

**Mathematics · Grade 3 · Term unspecified**

This educator-only file maps the generated memo to teach-back and misconception checks. The learner guide receives prompts only; keep this file and the memorandum with educators.

## 1.1 · 4 marks

**Question:** 1.1 How many bottle tops did the class collect altogether? Show your addition. [4]

**Bloom / family:** apply / calculation

**Memo points (educator use):**
- Chooses addition.
- Writes 24 + 18.
- Adds the ones correctly to make 12 ones.
- Gives 42 bottle tops.

## 1.2 · 4 marks

**Question:** 1.2 Use your total from Question 1.1 to put the bottle tops into bags of 6. Show a calculation or equal-groups drawing. State how many full bags you can make and whether any tops are left. [4]

**Bloom / family:** apply / equal_grouping

**Memo points (educator use):**
- Uses the total of 42 tops from Question 1.1, or consistently carries forward the learner's stated total.
- Shows division by 6 or a correct equal-groups/repeated-subtraction method.
- Calculates the quotient and remainder correctly for the total used (7 remainder 0 when using 42).
- States the number of full bags and any tops left, consistently with the calculation.

## 1.3 · 4 marks

**Question:** 1.3 Complete the pattern 5, 10, 15, __, __, state its rule and give the number that would be in the eighth position. [4]

**Bloom / family:** understand / pattern

**Memo points (educator use):**
- Writes 20 in the fourth position.
- Writes 25 in the fifth position.
- States that 5 is added each time.
- Gives 40 as the eighth term, continuing the rule correctly.

## 1.4 · 4 marks

**Question:** 1.4 A ribbon is 35 cm long. Sipho uses 12 cm. How much remains? [4]

**Bloom / family:** apply / measurement

**Memo points (educator use):**
- Chooses subtraction.
- Writes 35 - 12.
- Calculates 23.
- Includes centimetres in the answer.

## 1.5 · 4 marks

**Question:** 1.5 Name one 2-D shape with four straight sides and one object with that shape. [4]

**Bloom / family:** understand / geometry

**Memo points (educator use):**
- Names a square or rectangle.
- States that the chosen shape has four straight sides.
- Gives a plausible object with that 2-D shape.
- Distinguishes the flat 2-D shape from a solid object.

## Review

Confirm that the teaching sequence prepares learners for the assessment without teaching to a leaked answer key. Recheck memo accuracy and source permissions before classroom use.
