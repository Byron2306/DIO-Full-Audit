# HOMS Learning Studio · Exam-linked teaching map

> Generated from the same source-bound, educator-review-required spine as the exam. Draft planning aid only; question-level CAPS clause mapping is not asserted.

**Subject:** Economic and Management Sciences  
**Grade / phase:** 7 / senior_grade_7_9  
**Term:** Unspecified  
**Bloom targets:** analyze, apply, evaluate, understand

## Learning sequence anchored to the assessment

| Exam item | Prompt | Marks | Bloom / question type | Teaching use |
|---|---|---:|---|---|
| 1.1 | 1.1 For each item, say whether it is used to make the fruit cups, is a business expense, or both. Explain your choices for the fruit and the table fee. [6] | 6 | understand / business_concepts | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.2 | 1.2 Calculate revenue from the cups sold. [6] | 6 | apply / calculation | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.3 | 1.3 Calculate sales revenue and the cash remaining after the stated outlays. Explain why that cash balance alone does not establish profit. [8] | 8 | apply / budget | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.4 | 1.4 Explain two reasons the six unsold cups matter for the next market day. Use case facts to recommend how many cups to make or buy, and address freshness or safety, waste, and why unsold stock is not sales revenue. [10] | 10 | analyze / inventory_planning | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.5 | 1.5 Recommend one change for Lebo's next market day and support it with two calculations or facts from the case. [10] | 10 | evaluate / recommendation | Use as a retrieval check; teach prerequisite concepts before re-attempt. |

## Sources and visuals

- CAPS: Economic and Management Sciences · SHA-256 `313a25bf38f59a24df8180453aab57aa573d8aaf2564af4a342d0df2456ad8ea`

## Educator-only memo bridge

The matching memo remains a separate teacher artifact. Use it to build worked examples and misconception checks; do not place the memo in the learner-facing exam copy.

## Release gate

Subject expert verifies curriculum fit, source rights, answer accuracy, visual legibility, accessibility and classroom suitability before release.
