# HOMS Learning Studio · Exam-linked teaching map

> Generated from the same source-bound, educator-review-required spine as the exam. Draft planning aid only; question-level CAPS clause mapping is not asserted.

**Subject:** Life Skills  
**Grade / phase:** 1 / foundation_grade_r_3  
**Term:** Unspecified  
**Bloom targets:** apply, remember, understand

## Learning sequence anchored to the assessment

| Exam item | Prompt | Marks | Bloom / question type | Teaching use |
|---|---|---:|---|---|
| 1.1 | 1.1 Name two healthy things Nandi does and give one reason each is healthy. [4] | 4 | remember / identify_and_explain | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.2 | 1.2 What does Nandi do to use the slide safely? Give one other safe playground action and explain how each action helps keep children safe. [4] | 4 | understand / scenario_response | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.3 | 1.3 Her friend falls. Name four safe things Nandi can do while getting help. [4] | 4 | apply / safety_sequence | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.4 | 1.4 Starting with washing hands, put these actions in a helpful order: wash hands, sit to eat, play with a ball, tidy the ball away. [4] | 4 | apply / sequence | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.5 | 1.5 Give one kind way to help a classmate, say what you would do, and explain how it would help. [4] | 4 | understand / short_response | Use as a retrieval check; teach prerequisite concepts before re-attempt. |

## Sources and visuals

- CAPS: Life Skills · SHA-256 `4d4df1e5c4eb7db4157cd80f2a3b0cdb0a22b155474e432a3578c9a798845c1d`

## Educator-only memo bridge

The matching memo remains a separate teacher artifact. Use it to build worked examples and misconception checks; do not place the memo in the learner-facing exam copy.

## Release gate

Subject expert verifies curriculum fit, source rights, answer accuracy, visual legibility, accessibility and classroom suitability before release.
