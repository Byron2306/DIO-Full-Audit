# HOMS Learning Studio · Exam-linked teaching map

> Generated from the same source-bound, educator-review-required spine as the exam. Draft planning aid only; question-level CAPS clause mapping is not asserted.

**Subject:** Natural Sciences and Technology  
**Grade / phase:** 5 / intermediate_grade_4_6  
**Term:** Unspecified  
**Bloom targets:** analyze, evaluate, remember, understand

## Learning sequence anchored to the assessment

| Exam item | Prompt | Marks | Bloom / question type | Teaching use |
|---|---|---:|---|---|
| 1.1 | 1.1 Name the four materials mixed in the example and name the processed material they make. [5] | 5 | remember / materials_and_products | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.2 | 1.2 State what property information learners should record before mixing and after the samples set. Give two examples of properties to compare and explain why they record both stages. [5] | 5 | understand / observation | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.3 | 1.3 In the two-sample test, identify what is changed, what is measured and three conditions that should be kept the same. Explain why this makes the comparison fair. [6] | 6 | analyze / fair_test | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.4 | 1.4 Based on the planned test, predict which sample will support more counters, or predict that they will support the same number. Explain why your prediction is reasonable, state what result will count as evidence, and give one reason the result should be checked with repeated trials. [7] | 7 | evaluate / prediction | Use as a retrieval check; teach prerequisite concepts before re-attempt. |
| 1.5 | 1.5 Give suitable results-table headings, including units where needed, for the gravel test. Then describe one way to keep the comparison reliable and one limitation of using small samples to choose material for a real path. [7] | 7 | evaluate / data_handling | Use as a retrieval check; teach prerequisite concepts before re-attempt. |

## Sources and visuals

- CAPS: Natural Sciences and Technology · SHA-256 `4bf95cdcc20b1b7902a9ea65826d83624012b17f39b9d96287e1f18d40105b69`

## Educator-only memo bridge

The matching memo remains a separate teacher artifact. Use it to build worked examples and misconception checks; do not place the memo in the learner-facing exam copy.

## Release gate

Subject expert verifies curriculum fit, source rights, answer accuracy, visual legibility, accessibility and classroom suitability before release.
