# HOMS Assess pointwise educator adjudication

This file is a blank decision template. The model proposal is a draft for review, not a mark.

1. Open the linked learner submission, source question paper, and marking memo.
2. Review each `point_id` against the full learner answer and memo.
3. Enter `educator_verified_marks` only after review. It must be between 0 and `maximum_marks`.
4. Set `educator_decision` to `ACCEPT` when confirming the model proposal, `CHANGE` when replacing it, or `UNRESOLVED` when the evidence is insufficient.
5. For `CHANGE` or `UNRESOLVED`, explain the decision in `educator_rationale`. For unresolved rows, leave the verified mark blank.
5a. If a positive model proposal has no exact quote in this question's answer, enter an exact excerpt from that answer in `educator_verified_source_quote` before choosing `ACCEPT`. The validator checks the quote against the original question-scoped answer block; an ungrounded positive cannot be accepted with rationale alone.
6. Fill in reviewer identity and review time for every completed row. Blank fields remain unresolved; they are never interpreted as zero.

7. Review every source-bound marking-quality flag in `EDUCATOR_MARKING_QUALITY_FLAGS.csv`; select `RESOLVE` only when the underlying concern is addressed, or `UNRESOLVED` to keep totals blocked. Add a rationale, reviewer and timestamp.

8. `model_quote_candidates_not_bound_to_question_json` records candidate strings that are not exact spans in the current question's answer block. The state distinguishes text found elsewhere in the submission from text not found at all. Treat all candidates only as diagnostic clues; none can support a mark without an exact question-scoped binding and educator review.

9. `exact_question_source_quote_suggestions_json` contains at most two exact sentences from the same numbered answer, ranked by shared wording with the memo point. These are search aids only. Confirm that a sentence supports the point; never copy a suggestion into the verified quote field without checking the full response and memo. Suggestions do not change proposals or totals.

10. Use the review filters to narrow by learner or answer text. Download a JSON review draft to resume later; the draft contains educator-entered fields only and is bound to this packet fingerprint and row set. Loading a draft does not validate its decisions.

Validate both completed CSVs: `python scripts/validate_homs_assess_adjudication.py --run-dir <HOMS-Assess-run> --csv <completed-pointwise-csv> --quality-flags-csv <completed-quality-flags-csv>`.

When every point and quality flag is complete, validation calculates an educator-entered reconciliation subtotal and total for checking. These are not issued marks. It does not authorize gradebook entry or classroom release.
