# Mobile Care for Moya Clinic operations committee · landscape explainer

Story hash: `sha256:71bf1f68c091b10fe14865a64d873b57be167be019790371083417be9df418af`
Semantic law: `sha256:1ea601a36a5743de2b4679945061bd8ce20ffcb8d1c4e7b3049b8cbf10572b0c`
Projection: `sha256:d08257503b419c895116c8a0991a6420b5daf0dc7163078254c4056082d7a1a6`
Arc family: `general_professional_explainer`

## 1. Begin with the working reality

**Role:** question

For Moya Clinic operations committee, the pressure appears before any tool enters the picture: monthly site reports are split across five clinic spreadsheets.

Visual direction: Stay with the customer's real work long enough to establish the problem before showing a product surface.

## 2. Follow where the friction goes

**Role:** problem

The burden rarely stays in one place. It moves through handoffs, revisions and review, increasing the amount of specialist attention needed to reconstruct what happened.

Visual direction: Use a sequence of handoffs or revisions so the viewer sees the operational cost accumulate rather than hearing the same pain statement twice.

## 3. Make the handoff concrete

**Role:** workflow_demo

The bounded customer-facing result is one monthly view of scheduled and completed appointments.

Visual direction: Show the actual deliverable or review state as something a person can inspect, revise and either accept or reject.

## 4. Earn trust with something inspectable

**Role:** proof

The case for the workflow rests on inspectable evidence: the September service log records 240 completed appointments.

Visual direction: Move close to the proof object, source trail or product surface and let traceability carry the credibility.

## 5. Stop at the human boundary

**Role:** boundary

The workflow may prepare a bounded review state; judgement, commitment and release remain with the authorised human.

Visual direction: Show the system handing off to a human reviewer rather than completing the consequential action itself.

## 6. Reduce the next step to one case

**Role:** cta

A sensible next move is deliberately bounded: request the next-quarter schedule.

Visual direction: Close on a single concrete action and avoid urgency fiction, inflated outcome claims or automatic-release language.

## Semantic boundary

Creative form may change. Meaning, proof boundaries, human authority, publication hold, spend disablement and market-validation boundary may not.
